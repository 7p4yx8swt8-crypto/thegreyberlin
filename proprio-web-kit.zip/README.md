# PRÓPRIO Web-Kit — THE GREY

Assets & Daten, um thegrey.berlin auf die EINZIGE Kollektion PRÓPRIO umzustellen
(alle bisherigen Galerien werden entfernt).

- data/designs.json — maßgebliche Quelle: Kollektion (hero_id, reihenfolge, Prozess) + 8 Entwürfe
  (Name, Bedeutung, Format, Material, Kurz-/Langtext, Farben mit Pantone, Bildpfaden, Alt-Texten, hero-Flag).
- images/ — 8 Flat-Entwürfe, je WebP 1500/800/400 + JPEG 1500.
- downloads/ — Konzept-PDF PRÓPRIO.
- CLAUDE-CODE-TASK.md — Implementierungsauftrag (alles Alte löschen, nur PRÓPRIO, Hero = 1 Bild).

Standard: handgetuftet · 100 % Neuseelandwolle, matt. Hero-Bild via hero_id austauschbar (Default: GIRO).
