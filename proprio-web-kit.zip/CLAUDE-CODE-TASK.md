# Auftrag: thegrey.berlin — alle bestehenden Galerien löschen, NUR PRÓPRIO zeigen

## Kontext

Website: **https://thegrey.berlin**

THE GREY stellt den gesamten Galerie-/Kollektionsbereich der Website auf **eine einzige
Kollektion** um: **PRÓPRIO** (Wanna Do Collection N°4, 8 Entwürfe). **Alle bisherigen
Kollektionen/Galerien werden vollständig entfernt** — es soll ausschließlich PRÓPRIO
gezeigt werden. Assets und Daten liegen im Web-Kit (`proprio-web-kit.zip`):
`data/designs.json` (maßgeblich), `images/`, `downloads/`.

**Auftritt:** Der allererste Eindruck ist **ein einziges Hero-Bild** (der Entwurf mit
`hero: true` bzw. `kollektion.hero_id`, aktuell GIRO), großflächig, viel Weißraum,
darunter dezent der Kollektionsname. Beim Scrollen erscheinen die übrigen sieben Entwürfe
als ruhiger, editorialer Stream. Klar, exklusiv, galerieartig — kein Katalog-Look.

## Schritt 0 — Discovery (zuerst!)

1. Repo analysieren: Framework/CMS, Routing, Templating, Build, Bild-Handling, Fonts/Tokens.
2. Live-Site **https://thegrey.berlin** crawlen: ALLE bestehenden Galerie-/Kollektions-URLs
   erfassen (für 301-Redirects) sowie Navigation/Typografie.
3. **Alle** bestehenden Galerie-/Kollektionsinhalte im Repo und ggf. CMS identifizieren
   (Routen, Templates, Komponenten, Bilder, Datensätze). Entfernungsplan erstellen.
   Reihenfolge: erst die neue PRÓPRIO-Seite bauen und verifizieren, dann alles Alte
   entfernen, dann Redirects setzen.
4. Auftrag an die vorgefundene Architektur anpassen. `designs.json` ist die einzige
   inhaltliche Quelle; nichts hartkodieren, was dort steht.

## Informationsarchitektur

- **Eine** Kollektionsseite unter dem bisherigen Galerie-Haupt-URL (bzw. `/proprio`):
  zeigt ausschließlich PRÓPRIO.
- `/<id>` bzw. `/proprio/<id>` — Permalink je Entwurf (8 Stück, `id` z. B.
  `proprio-03-giro`): rendert die Detailansicht als vollwertige Seite (SEO/Teilen). Im
  Stream öffnet der Klick ein Overlay + History-API-URL.
- **Alle** alten Galerie-/Kollektions-URLs per **301** auf die neue PRÓPRIO-Seite.
- Keine Filter, keine Kollektions-Umschalter, keine anderen Kollektionen — es gibt nur eine.

## Seitenaufbau

1. **Hero (erster Screen):** ein einziges großes Bild (`hero_id`), zentriert, mit viel
   Weißraum, formatfüllend aber nicht randlos (Luft ringsum). Darunter dezent:
   Kicker „THE GREY — WANNA DO COLLECTION N° 4", Kollektionsname **PRÓPRIO** (groß),
   eine Zeile Claim (`kollektion.claim`), ein leiser Scroll-Hinweis. Kein Text-Overload,
   keine Navigation über dem Bild. Der Hero füllt (nahezu) den ersten Viewport.
2. **Stream:** Beim Scrollen die weiteren Entwürfe in der Reihenfolge
   `kollektion.reihenfolge` (der Hero steht dort an erster Stelle und wird im Stream nicht
   doppelt großformatig wiederholt — er ist bereits der Hero; ab dem zweiten Eintrag geht
   der Stream los). Ein Entwurf pro Abschnitt, großzügig, editorial: großes Bild + Text
   (Micro-Zeile mit Code · Format · Typ, Name in groß, kursive Bedeutung `name_bedeutung`,
   `text_kurz`, Palette-Chips, „Geschichte lesen"). Ruhiger Rhythmus, viel Weißraum,
   alternierend Bild links/rechts ist erlaubt.
3. **Detail/Overlay + Permalink:** großes Bild links auf getöntem Grund, rechts Micro-Zeile,
   Name, Bedeutung, `text_lang`, Palette-Chips (Name + `pantone_fhi` als Unterzeile),
   Spezifikation in Versalien-Kleintext (`format_cm` + „frei skalierbar", `grund`,
   `material`, `herstellung`, `eignung`), CTA.
4. **CTA:** „Wanna do? — Anfragen" → bestehender Kontaktweg der Website, Betreff vorbefüllt
   „Wanna do: <code> <Name>".
5. **Footer:** Standard-Spezifikation + Download des Konzept-PDF (`downloads/…proprio…pdf`).

## Gestaltung

- Papier #FAF9F6 / #F6F4EF · Ink #1F1D1A · Sekundär #7A7468 · Haarlinie #DED8CB ·
  Overlay-Bildgrund #EBE7DE. Vorhandene Website-Typografie nutzen; Micro-Labels in
  Versalien mit ~0.24em Letterspacing, Namen groß und ruhig.
- Clean/Flat: die Bilder sind randscharfe Volltonflächen — KEINE zusätzlichen CSS-Schatten
  oder Filter auf den Bildern, keine runden Ecken, keine Icons. Weißraum und Haarlinien
  strukturieren.
- Dezentes Scroll-Reveal (einmalig, `prefers-reduced-motion` respektieren), sanfte
  Overlay-Transition. Der Hero darf ruhig statisch sein — Ruhe ist gewollt.

## Technik

- Bilder: `<picture>`, WebP-Srcset 400/800/1500 + JPEG-Fallback; Hero eager laden, Rest
  `loading="lazy"`; Bildmaße gesetzt (kein Layout-Shift); `alt` aus `alt_text`.
- SEO: Permalinks mit Title/Meta/OG (OG-Image = JPEG 1500); `CreativeWork`/`Product`
  (ohne Preis); Startseite mit sinnvollem Title/Description für PRÓPRIO.
- A11y: Overlay als Dialog (Fokus-Trap, ESC), Farbchips mit Textlabel im DOM, semantische
  Headings, Tastaturbedienung.
- Performance: erste Seite < 1,2 MB initial (Hero-Bild optimiert); Lighthouse Performance
  & A11y ≥ 90 (Startseite + ein Permalink).

## Nicht tun

- Keine anderen Kollektionen, keine Reste der alten Galerie (Bilder, Routen, Menüpunkte,
  CMS-Einträge) übrig lassen.
- Keine Wohnszenario-Mockups, keine Preise.
- Spezifikations-Wording nicht verändern (Standard: handgetuftet · 100 % Neuseelandwolle,
  matt; Specials nur nach individueller Besprechung).
- Den ersten Screen nicht mit mehreren Bildern oder viel Text füllen — bewusst EIN Bild.

## Akzeptanzkriterien

1. Auf der gesamten Website ist ausschließlich PRÓPRIO sichtbar; alle früheren Galerien/
   Kollektionen sind entfernt, alte URLs per 301 umgeleitet, keine toten Links (Crawl).
2. Erster Viewport = ein einziges Hero-Bild + Kollektionsname; kein zweites Bild „above the
   fold".
3. Alle 8 Entwürfe: Kurztext ohne Klick sichtbar (im Stream), Volltext + Spezifikation +
   CTA nach genau einem Klick; Permalinks funktionieren als Standalone-Seiten.
4. Inhalte vollständig aus `designs.json` (nichts hartkodiert); Hero über `hero_id`
   austauschbar (ein Wert).
5. Bilder als WebP mit JPEG-Fallback, korrekt lazy/eager, mit Alt-Texten; Lighthouse-Ziele
   erreicht.
6. Konzept-PDF-Download erreichbar; CTA mit vorbefülltem Betreff funktioniert.
7. Mobile (375 px) und Desktop (1440 px) geprüft.
